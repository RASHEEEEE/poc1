package com.ras.nvda_stock.stock;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface StockRepository extends JpaRepository<Stock, Date> {
}
