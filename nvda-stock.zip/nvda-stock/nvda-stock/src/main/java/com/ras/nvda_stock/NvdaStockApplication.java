package com.ras.nvda_stock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NvdaStockApplication {

	public static void main(String[] args) {
		SpringApplication.run(NvdaStockApplication.class, args);
	}

}
