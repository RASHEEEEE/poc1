package com.ras.nvda_stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NvdaStockApplicationTests {

	@Test
	void contextLoads() {
	}

}
